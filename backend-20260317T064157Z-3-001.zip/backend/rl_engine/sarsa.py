import numpy as np
from typing import Tuple, Dict, Any
from .base import BaseAlgorithm
import torch
import torch.nn as nn
import random

class SARSAAlgorithm(BaseAlgorithm):
    """
    SARSA (On-Policy) for tabular states.
    Uses a dict-based Q-table.
    """
    def __init__(self, state_dim: int, action_dim: int, config: Dict[str, Any]):
        super().__init__(state_dim, action_dim, config)
        self.q_table = {} # (state_tuple) -> [q_actions]
        self.prev_state = None
        self.prev_action = None
        self.prev_reward = None

    def _build_model(self) -> nn.Module:
        # Dummy model for BaseAlgorithm compatibility
        return nn.Linear(1, 1)

    def _get_q_values(self, state: np.ndarray) -> np.ndarray:
        state_key = tuple(state.tolist())
        if state_key not in self.q_table:
            self.q_table[state_key] = np.zeros(self.action_dim)
        return self.q_table[state_key]

    def select_action(self, state: np.ndarray, training: bool = True) -> Tuple[int, Dict[str, Any]]:
        q_values = self._get_q_values(state)
        
        if training and random.random() < self.epsilon:
            action = random.randint(0, self.action_dim - 1)
        else:
            action = int(np.argmax(q_values))
            
        metrics = {
            "q_values": q_values.tolist(),
            "epsilon": self.epsilon
        }
        return action, metrics

    def update_step(self, state: np.ndarray, action: int, reward: float, next_state: np.ndarray, done: bool):
        """
        SARSA update: Q(s,a) = Q(s,a) + alpha * [r + gamma * Q(s',a') - Q(s,a)]
        """
        # We need the next action (A') to perform the SARSA update for the current step.
        # In this implementation, we update the PREVIOUS step using the CURRENT action.
        
        if self.prev_state is not None:
            prev_q_vals = self._get_q_values(self.prev_state)
            current_q_vals = self._get_q_values(state)
            
            # The current 'action' is A', the action chosen at S_t
            # The prev_action was A_{t-1}, chosen at S_{t-1}
            # target = reward_{t-1} + gamma * Q(S_t, A_t)
            target = self.prev_reward + self.gamma * current_q_vals[action]
            
            # Update Q(S_{t-1}, A_{t-1})
            td_error = target - prev_q_vals[self.prev_action]
            prev_q_vals[self.prev_action] += self.lr * td_error

        # If terminal, we update the current step (S_t, A_t) with target = r
        if done:
            q_vals = self._get_q_values(state)
            td_error = reward - q_vals[action]
            q_vals[action] += self.lr * td_error
            
            # Reset for next episode
            self.prev_state = None
            self.prev_action = None
            self.prev_reward = None
            
            # Decay epsilon
            self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
        else:
            # Store current for next step update
            self.prev_state = state
            self.prev_action = action
            self.prev_reward = reward

    def update(self) -> Dict[str, float]:
        # Handled in update_step; return dummy
        return {"loss": 0.0}
