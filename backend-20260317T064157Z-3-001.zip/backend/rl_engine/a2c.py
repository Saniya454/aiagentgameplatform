import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
from typing import Tuple, Dict, Any, List
from .base import BaseAlgorithm

class A2CAlgorithm(BaseAlgorithm):
    def __init__(self, state_dim: int, action_dim: int, config: Dict[str, Any]):
        # BaseAlgorithm calls _build_model, so we must be careful with layers
        super().__init__(state_dim, action_dim, config)

    def _build_model(self) -> nn.Module:
        # Define layers here so they are available when BaseAlgorithm calls _build_model
        self.affine = nn.Linear(self.state_dim, 128)
        self.action_head = nn.Linear(128, self.action_dim)
        self.value_head = nn.Linear(128, 1)
        return nn.ModuleList([self.affine, self.action_head, self.value_head])

    def forward(self, x):
        x = F.relu(self.affine(x))
        action_probs = F.softmax(self.action_head(x), dim=-1)
        state_values = self.value_head(x)
        return action_probs, state_values

    def select_action(self, state: np.ndarray, training: bool = True) -> Tuple[int, Dict[str, Any]]:
        state_t = torch.FloatTensor(state).to(self.device)
        probs, _ = self.forward(state_t)
        
        dist = torch.distributions.Categorical(probs)
        action = dist.sample()
        
        metrics = {
            "probabilities": probs.detach().cpu().numpy().tolist(),
            "confidence": probs.max().item()
        }
        return action.item(), metrics

    def update_step(self, state, action, reward, next_state, done):
        state_t = torch.FloatTensor(state).to(self.device)
        next_state_t = torch.FloatTensor(next_state).to(self.device)
        
        probs, value = self.forward(state_t)
        _, next_value = self.forward(next_state_t)
        
        target = reward + (1 - done) * self.gamma * next_value.detach()
        advantage = target - value.detach()
        
        # Loss = Policy Loss + Value Loss
        dist = torch.distributions.Categorical(probs)
        policy_loss = -dist.log_prob(torch.tensor(action).to(self.device)) * advantage
        value_loss = F.mse_loss(value, target)
        
        loss = policy_loss + value_loss
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        return loss.item()

    def update(self) -> Dict[str, float]:
        # Step-based update; return avg loss placeholder
        return {"loss": 0.0}
