import torch
import torch.nn as nn
from abc import ABC, abstractmethod
from typing import Tuple, Dict, Any
import numpy as np

class BaseAlgorithm(ABC):
    """
    Abstract Base Class for Reinforcement Learning Algorithms.
    """
    
    def __init__(self, state_dim: int, action_dim: int, config: Dict[str, Any]):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.lr = config.get('learning_rate', 0.001)
        self.gamma = config.get('discount_factor', 0.99)
        self.epsilon = config.get('exploration_rate', 1.0)
        self.epsilon_min = config.get('epsilon_min', 0.01)
        self.epsilon_decay = config.get('epsilon_decay', 0.995)
        
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = self._build_model().to(self.device)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr)
        
    @abstractmethod
    def _build_model(self) -> nn.Module:
        pass
        
    @abstractmethod
    def select_action(self, state: np.ndarray, training: bool = True) -> Tuple[int, Dict[str, Any]]:
        """
        Selects an action based on current state.
        Returns:
            action (int): The chosen action.
            metrics (dict): Additional interpretability metrics (e.g., q-values, reasoning, probabilities)
        """
        pass
        
    @abstractmethod
    def update(self) -> Dict[str, float]:
        """
        Updates the model parameters based on collected experience / memory.
        Returns useful metrics like loss for logging.
        """
        pass
        
    def save(self, filepath: str):
        torch.save(self.model.state_dict(), filepath)
        
    def load(self, filepath: str):
        self.model.load_state_dict(torch.load(filepath, map_location=self.device))
        self.model.eval()
