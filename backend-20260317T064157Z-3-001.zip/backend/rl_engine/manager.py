import threading
import time
import datetime
import os
import traceback
import torch
import numpy as np
from extensions import db, socketio
from models import Agent, MatchHistory
import rl_engine.factory as factory
import environments.factory as env_factory

active_training_sessions = {}
active_arena_matches = {}

def training_worker(app, agent_id, config):
    with app.app_context():
        try:
            agent = Agent.query.get(agent_id)
            if not agent:
                return

            agent.status = 'training'
            db.session.commit()

            game_name = agent.game
            algo_name = agent.algorithm
            episodes = int(config.get('episodes', agent.episodes))
            
            print(f"Starting training session for agent {agent_id}. Game: {game_name}, Algo: {algo_name}, Total Episodes: {episodes}")
            
            # Compatibility Check
            if config.get('game') and config.get('game').lower() != game_name.lower():
                 raise ValueError(f"Agent game mismatch. Agent: {game_name}, Config: {config.get('game')}")

            env = env_factory.create_environment(game_name)
            algo = factory.create_algorithm(algo_name, env.state_space, env.action_space, config)

            reward_history = []
            win_history = []  # per-episode win/loss (1=win, 0=loss/draw)
            start_time = time.time()
            total_steps = 0
            epsilon = getattr(algo, 'epsilon', 1.0)
            
            for episode in range(episodes):
                state = env.reset()
                total_reward = 0
                done = False
                episode_won = 0
                
                while not done:
                    # Generic algorithm interaction
                    action, metrics = algo.select_action(state, training=True)
                    next_state, reward, done, info = env.step(action)
                    
                    # Store transition (for DQN, SARSA etc)
                    if hasattr(algo, 'store_transition'):
                        algo.store_transition(state, action, reward, next_state, done)
                    
                    # Periodic update
                    algo_metrics = algo.update()
                    
                    state = next_state
                    total_reward += reward
                    total_steps += 1
                    
                    # Update episode win status based on various criteria
                    if done:
                        if info.get('winner') is not None:
                            # 1 as player 1, 2 as player 2 (convention)
                            if info.get('winner') == 1: episode_won = 1
                        elif info.get('score', 0) > 0:
                            # Success in single player games (Snake eating food, Treasure found)
                            episode_won = 1
                        elif reward > 0:
                            # Final success reward
                            episode_won = 1
                        elif total_reward > 5:
                            # Significant positive experience
                            episode_won = 1
                    
                reward_history.append(total_reward)
                win_history.append(episode_won)
                epsilon = getattr(algo, 'epsilon', epsilon)
                
                # Higher frequency updates via Socket.IO for "High-Speed" feel
                if episode % 2 == 0 or episode == episodes - 1:
                    elapsed = time.time() - start_time
                    sps = total_steps / elapsed if elapsed > 0 else 0
                    avg_reward = float(np.mean(reward_history[-100:])) if reward_history else 0
                    win_rate = float(np.mean(win_history[-100:])) if win_history else 0
                    win_rate_history = [float(x) for x in win_history[-200:]]
                    recent_rewards = [float(x) for x in reward_history[-100:]]
                    
                    # Capture board render
                    board_snapshot = env.render()
                    
                    socketio.emit('training_update', {
                        'agent_id': agent_id,
                        'episode': episode,
                        'currentEpisode': episode,
                        'totalEpisodes': episodes,
                        'reward': avg_reward,
                        'avgReward': avg_reward,
                        'winRate': win_rate,
                        'epsilon': float(epsilon),
                        'status': 'training',
                        'reward_history': recent_rewards,
                        'rewardHistory': recent_rewards,
                        'winRateHistory': win_rate_history,
                        'sps': round(sps, 2),
                        'board': board_snapshot,
                        'log': f"Episode {episode}/{episodes} | Win Rate: {win_rate:.1%} | Avg Reward: {avg_reward:.2f} | ε: {float(epsilon):.3f}"
                    }, namespace='/training', room=f"agent_{agent_id}")
                    
                    # CRITICAL: Yield control to let eventlet process the emitted events
                    socketio.sleep(0)

            # Save model
            model_dir = 'storage'
            if not os.path.exists(model_dir):
                os.makedirs(model_dir)
            model_path = os.path.join(model_dir, f"agent_{agent_id}.pt")
            algo.save(model_path)

            final_win_rate = float(np.mean(win_history[-100:])) if win_history else 0
            agent.model_path = model_path
            agent.status = 'completed'
            agent.final_reward = float(np.mean(reward_history[-100:])) if reward_history else 0
            agent.matches_played = len(win_history)
            agent.matches_won = int(sum(win_history))
            db.session.commit()

            socketio.emit('training_update', {
                'agent_id': agent_id,
                'episode': episodes,
                'currentEpisode': episodes,
                'totalEpisodes': episodes,
                'reward': agent.final_reward,
                'avgReward': agent.final_reward,
                'winRate': final_win_rate,
                'epsilon': 0.0,
                'status': 'completed',
                'winRateHistory': [float(x) for x in win_history],
                'rewardHistory': [float(x) for x in reward_history],
                'log': f"Training complete! Win Rate: {final_win_rate:.1%} | Avg Reward: {agent.final_reward:.2f}"
            }, namespace='/training', room=f"agent_{agent_id}")

        except Exception as e:
            print(f"Error in training worker: {e}")
            traceback.print_exc()
            with app.app_context():
                agent = Agent.query.get(agent_id)
                if agent:
                    agent.status = 'failed'
                    db.session.commit()
            
            try:
                socketio.emit('training_update', {
                    'agent_id': agent_id,
                    'status': 'failed',
                    'error': str(e)
                }, namespace='/training', room=f"agent_{agent_id}")
            except Exception as emit_err:
                print(f"Failed to emit failure status: {emit_err}")

def start_training_session(app, agent_id, config):
    thread = threading.Thread(target=training_worker, args=(app, agent_id, config))
    thread.daemon = True
    thread.start()
    active_training_sessions[agent_id] = thread

def arena_worker(app, match_id, agent1_id, agent2_id, game_name):
    with app.app_context():
        try:
            env = env_factory.create_environment(game_name)
            
            # Load Agents
            agent1_db = Agent.query.get(agent1_id)
            agent2_db = Agent.query.get(agent2_id)
            
            # Validate Agent-Game Compatibility
            if agent1_db.game.lower() != game_name.lower() or agent2_db.game.lower() != game_name.lower():
                raise ValueError(f"Agent game mismatch. Agent 1: {agent1_db.game}, Agent 2: {agent2_db.game}, Game: {game_name}")

            algo1 = factory.create_algorithm(agent1_db.algorithm, env.state_space, env.action_space, agent1_db.hyperparameters if hasattr(agent1_db, 'hyperparameters') else {})
            algo2 = factory.create_algorithm(agent2_db.algorithm, env.state_space, env.action_space, agent2_db.hyperparameters if hasattr(agent2_db, 'hyperparameters') else {})
            
            if agent1_db.model_path and os.path.exists(agent1_db.model_path):
                algo1.load(agent1_db.model_path)
            if agent2_db.model_path and os.path.exists(agent2_db.model_path):
                algo2.load(agent2_db.model_path)
            
            state = env.reset()
            done = False
            
            socketio.emit('arena_start', {
                'match_id': match_id,
                'game': game_name,
                'agent1': agent1_db.name,
                'agent2': agent2_db.name
            }, namespace='/arena', room=f"match_{match_id}")

            last_reward = 0
            while not done:
                # Agent 1 turn
                action1, metrics1 = algo1.select_action(state, training=False)
                next_state, reward, done, info = env.step(action1)
                last_reward = reward
                
                socketio.emit('arena_state', {
                    'match_id': match_id,
                    'board': env.render(),
                    'current_player': agent1_db.name,
                    'last_move': int(action1 if isinstance(action1, (int, np.integer)) else action1[0] if isinstance(action1, (list, tuple)) else 0),
                    'q_values': metrics1.get('q_values', {}),
                    'metrics': metrics1,
                    'done': done
                }, namespace='/arena', room=f"match_{match_id}")
                
                state = next_state
                time.sleep(0.5) 
                
                if done: break
                
                # Note: Currently many environments handle the second player (opponent)
                # internally with a random heuristic. For multi-agent arena, 
                # environments should be updated to a multi-agent interface.
                
            # Log Match
            # Determine winner based on last reward and info
            winner_id = None
            if last_reward > 0:
                winner_id = agent1_id
            elif last_reward < 0:
                winner_id = agent2_id
            
            match = MatchHistory(
                agent1_id=agent1_id,
                agent2_id=agent2_id,
                winner_id=winner_id,
                game=game_name,
                score_agent1=float(last_reward) if last_reward > 0 else 0.0,
                score_agent2=float(-last_reward) if last_reward < 0 else 0.0
            )
            db.session.add(match)
            db.session.commit()
            
            winner_name = "Draw"
            if winner_id == agent1_id: winner_name = agent1_db.name
            elif winner_id == agent2_id: winner_name = agent2_db.name

            socketio.emit('arena_complete', {
                'match_id': match_id,
                'winner': winner_name,
                'last_reward': float(last_reward)
            }, namespace='/arena', room=f"match_{match_id}")

        except Exception as e:
            print(f"Error in arena worker: {e}")
            traceback.print_exc()

def start_arena_match(app, match_id, agent1_id, agent2_id, game_name):
    thread = threading.Thread(target=arena_worker, args=(app, match_id, agent1_id, agent2_id, game_name))
    thread.daemon = True
    thread.start()
    active_arena_matches[match_id] = thread
