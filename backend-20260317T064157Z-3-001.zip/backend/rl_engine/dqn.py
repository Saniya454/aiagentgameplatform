import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
from collections import deque
from typing import Tuple, Dict, Any, List
from .base import BaseAlgorithm

class DQNNetwork(nn.Module):
    def __init__(self, state_dim: int, action_dim: int):
        super(DQNNetwork, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, action_dim)
        )

    def forward(self, x):
        return self.net(x)

class DQNAlgorithm(BaseAlgorithm):
    def __init__(self, state_dim: int, action_dim: int, config: Dict[str, Any]):
        super().__init__(state_dim, action_dim, config)
        self.target_model = self._build_model().to(self.device)
        self.target_model.load_state_dict(self.model.state_dict())
        
        self.memory = deque(maxlen=config.get('memory_size', 10000))
        self.batch_size = config.get('batch_size', 64)
        self.target_update_freq = config.get('target_update_freq', 100)
        self.steps_done = 0

    def _build_model(self) -> nn.Module:
        return DQNNetwork(self.state_dim, self.action_dim)

    def select_action(self, state: np.ndarray, training: bool = True) -> Tuple[int, Dict[str, Any]]:
        state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            q_values = self.model(state_t)
            
        if training and random.random() < self.epsilon:
            action = random.randint(0, self.action_dim - 1)
        else:
            action = int(q_values.argmax().item())
            
        metrics = {
            "q_values": q_values.cpu().numpy().flatten().tolist(),
            "epsilon": self.epsilon,
            "reasoning": f"Random exploration move (epsilon={self.epsilon:.3f})" if training and random.random() < self.epsilon else f"Neural network predicted highest reward of {q_values.cpu().numpy().flatten()[action]:.4f} for action {action}"
        }
        return action, metrics

    def store_transition(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))

    def update(self) -> Dict[str, float]:
        if len(self.memory) < self.batch_size:
            return {"loss": 0.0}
            
        batch = random.sample(self.memory, self.batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        
        states_t = torch.FloatTensor(np.array(states)).to(self.device)
        actions_t = torch.LongTensor(np.array(actions)).unsqueeze(1).to(self.device)
        rewards_t = torch.FloatTensor(np.array(rewards)).to(self.device)
        next_states_t = torch.FloatTensor(np.array(next_states)).to(self.device)
        dones_t = torch.FloatTensor(np.array(dones)).to(self.device)
        
        current_q = self.model(states_t).gather(1, actions_t).squeeze()
        
        with torch.no_grad():
            next_q = self.target_model(next_states_t).max(1)[0]
            target_q = rewards_t + (1 - dones_t) * self.gamma * next_q
            
        loss = nn.MSELoss()(current_q, target_q)
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        self.steps_done += 1
        if self.steps_done % self.target_update_freq == 0:
            self.target_model.load_state_dict(self.model.state_dict())
            
        # Decay epsilon
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
        
        return {"loss": loss.item()}
