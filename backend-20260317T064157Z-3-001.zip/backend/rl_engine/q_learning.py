import numpy as np
from typing import Tuple, Dict, Any
from .base import BaseAlgorithm
import torch
import torch.nn as nn
import random

class QLearningAlgorithm(BaseAlgorithm):
    """
    Standard Q-Learning for tabular states.
    Uses a simple dict-based Q-table.
    """
    def __init__(self, state_dim: int, action_dim: int, config: Dict[str, Any]):
        super().__init__(state_dim, action_dim, config)
        self.q_table = {} # (state_tuple) -> [q_actions]

    def _build_model(self) -> nn.Module:
        # For tabular Q-learning, we don't strictly need a PyTorch model,
        # but we'll return a dummy one to satisfy BaseAlgorithm.
        return nn.Linear(1, 1)

    def _get_q_values(self, state: np.ndarray) -> np.ndarray:
        state_key = tuple(state.tolist())
        if state_key not in self.q_table:
            self.q_table[state_key] = np.zeros(self.action_dim)
        return self.q_table[state_key]

    def select_action(self, state: np.ndarray, training: bool = True) -> Tuple[int, Dict[str, Any]]:
        q_values = self._get_q_values(state)
        
        if training and random.random() < self.epsilon:
            action = random.randint(0, self.action_dim - 1)
        else:
            action = int(np.argmax(q_values))
            
        metrics = {
            "q_values": q_values.tolist(),
            "epsilon": self.epsilon,
            "reasoning": f"Exploration (e-greedy) move" if training and random.random() < self.epsilon else f"Best action {action} chosen with Q-value {q_values[action]:.4f}"
        }
        return action, metrics

    def update_step(self, state: np.ndarray, action: int, reward: float, next_state: np.ndarray, done: bool):
        current_q = self._get_q_values(state)[action]
        next_max_q = np.max(self._get_q_values(next_state)) if not done else 0
        
        # Q-Learning formula: Q(s,a) = Q(s,a) + lr * (reward + gamma * max(Q(s',a')) - Q(s,a))
        new_q = current_q + self.lr * (reward + self.gamma * next_max_q - current_q)
        
        state_key = tuple(state.tolist())
        self.q_table[state_key][action] = new_q
        
        if done:
            self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)

    def update(self) -> Dict[str, float]:
        return {"loss": 0.0}
