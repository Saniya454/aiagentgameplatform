import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
from typing import Tuple, Dict, Any, List
from .base import BaseAlgorithm

class ActorCritic(nn.Module):
    def __init__(self, state_dim: int, action_dim: int):
        super(ActorCritic, self).__init__()
        self.affine = nn.Linear(state_dim, 128)
        self.action_head = nn.Linear(128, action_dim)
        self.value_head = nn.Linear(128, 1)

    def forward(self, x):
        x = F.relu(self.affine(x))
        state_values = self.value_head(x)
        action_probs = F.softmax(self.action_head(x), dim=-1)
        return action_probs, state_values

class PPOAlgorithm(BaseAlgorithm):
    def __init__(self, state_dim: int, action_dim: int, config: Dict[str, Any]):
        super().__init__(state_dim, action_dim, config)
        self.policy_old = ActorCritic(state_dim, action_dim).to(self.device)
        self.policy_old.load_state_dict(self.model.state_dict())
        
        self.K_epochs = config.get('ppo_epochs', 4)
        self.eps_clip = config.get('eps_clip', 0.2)
        self.M_step = 0
        
        self.buffer_states = []
        self.buffer_actions = []
        self.buffer_logprobs = []
        self.buffer_rewards = []
        self.buffer_is_terminals = []

    def _build_model(self) -> nn.Module:
        return ActorCritic(self.state_dim, self.action_dim)

    def select_action(self, state: np.ndarray, training: bool = True) -> Tuple[int, Dict[str, Any]]:
        state_t = torch.FloatTensor(state).to(self.device)
        with torch.no_grad():
            action_probs, _ = self.policy_old(state_t)
            
        dist = torch.distributions.Categorical(action_probs)
        action = dist.sample()
        
        if training:
            self.buffer_states.append(state_t)
            self.buffer_actions.append(action)
            self.buffer_logprobs.append(dist.log_prob(action))
            
        metrics = {
            "probabilities": action_probs.cpu().numpy().tolist(),
            "confidence": action_probs.max().item(),
            "reasoning": f"Stochastic policy sampled action {action.item()} with {action_probs[action.item()].item()*100:.1f}% probability"
        }
        return action.item(), metrics

    def update(self) -> Dict[str, float]:
        if not self.buffer_rewards:
            return {"loss": 0.0}
            
        # Monte Carlo estimate of rewards
        rewards = []
        discounted_reward = 0
        for reward, is_terminal in zip(reversed(self.buffer_rewards), reversed(self.buffer_is_terminals)):
            if is_terminal:
                discounted_reward = 0
            discounted_reward = reward + (self.gamma * discounted_reward)
            rewards.insert(0, discounted_reward)
            
        # Normalizing the rewards
        rewards = torch.tensor(rewards, dtype=torch.float32).to(self.device)
        rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-7)
        
        old_states = torch.stack(self.buffer_states).detach()
        old_actions = torch.stack(self.buffer_actions).detach()
        old_logprobs = torch.stack(self.buffer_logprobs).detach()
        
        loss_val = 0
        for _ in range(self.K_epochs):
            logprobs, state_values = self.model(old_states)
            dist = torch.distributions.Categorical(logprobs)
            logprobs = dist.log_prob(old_actions)
            dist_entropy = dist.entropy()
            
            # Finding the ratio (pi_theta / pi_theta__old)
            ratios = torch.exp(logprobs - old_logprobs.detach())
            
            # Finding Surrogate Loss
            advantages = rewards - state_values.detach().squeeze()
            surr1 = ratios * advantages
            surr2 = torch.clamp(ratios, 1-self.eps_clip, 1+self.eps_clip) * advantages
            
            loss = -torch.min(surr1, surr2) + 0.5*nn.MSELoss()(state_values.squeeze(), rewards) - 0.01*dist_entropy
            
            self.optimizer.zero_grad()
            loss.mean().backward()
            self.optimizer.step()
            loss_val += loss.mean().item()
            
        self.policy_old.load_state_dict(self.model.state_dict())
        self.clear_buffer()
        return {"loss": loss_val / self.K_epochs}

    def clear_buffer(self):
        del self.buffer_states[:]
        del self.buffer_actions[:]
        del self.buffer_logprobs[:]
        del self.buffer_rewards[:]
        del self.buffer_is_terminals[:]
