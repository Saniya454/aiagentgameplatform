import io from 'socket.io-client';

const API_BASE_URL = '/api'; // Use proxy in vite.config.ts

export interface Agent {
  id: string;
  name: string;
  game: string;
  algorithm: string;
  type: string; // Aliased for UI compatibility
  status: 'pending' | 'training' | 'completed' | 'failed';
  episodes: number;
  learning_rate: number;
  final_reward?: number;
  matches_won: number;
  matches_played: number;
  created_at: string;
  trainable?: boolean;
  trained?: boolean;
}

export interface Game {
  id: string;
  name: string;
  description: string;
  boardSize: [number, number];
  supportedAgents: string[];
}

export interface TrainingProgress {
  agent_id: string;
  episode: number;
  reward: number;
  status: string;
  currentEpisode: number;
  totalEpisodes: number;
  winRate: number;
  avgReward: number;
  epsilon: number;
  rewardHistory: number[];
  winRateHistory: number[];
  sps?: number;
  board?: any;
  logs?: string[];
  log?: string;
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  owner: string;
  game: string;
  matches_won: number;
  matches_played: number;
  win_rate: number;
}

class ArenaAPI {
  private token: string | null = localStorage.getItem('token');
  private socket: any = null;

  setToken(token: string | null) {
    this.token = token;
    if (token) localStorage.setItem('token', token);
    else localStorage.removeItem('token');
  }

  private async fetch<T>(endpoint: string, options?: RequestInit & { skipRedirect?: boolean }): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers: {
        ...headers,
        ...options?.headers,
      },
    });

    if (response.status === 401 && !options?.skipRedirect) {
      this.setToken(null);
      window.location.href = '/login';
      throw new Error('Unauthorized');
    }

    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: response.statusText }));
      throw new Error(error.message || `API Error: ${response.statusText}`);
    }

    return response.json();
  }

  // Auth
  async login(username: string, password: string): Promise<any> {
    const data = await this.fetch<any>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
      skipRedirect: true // Don't redirect if login itself fails
    });
    this.setToken(data.access_token);
    return data;
  }

  async register(username: string, email: string, password: string): Promise<any> {
    return this.fetch('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ username, email, password }),
      skipRedirect: true
    });
  }

  async getProfile(skipRedirect: boolean = false): Promise<any> {
    return this.fetch('/auth/me', { skipRedirect });
  }

  // Agents
  async getAgents(skipRedirect: boolean = false): Promise<Agent[]> {
    const data = await this.fetch<{ agents: any[] }>('/agents/', { skipRedirect });
    return data.agents.map(a => ({
      ...a,
      type: a.algorithm // Map algorithm to type for UI
    }));
  }

  async createAgent(config: any): Promise<any> {
    return this.fetch('/agents/', {
      method: 'POST',
      body: JSON.stringify(config),
    });
  }

  async deleteAgent(agentId: string): Promise<any> {
    return this.fetch(`/agents/${agentId}`, {
      method: 'DELETE',
    });
  }

  // Stats & Leaderboard
  async getLeaderboard(): Promise<LeaderboardEntry[]> {
    const data = await this.fetch<{ leaderboard: LeaderboardEntry[] }>('/stats/leaderboard', { skipRedirect: true });
    return data.leaderboard;
  }

  async getDashboard(skipRedirect: boolean = false): Promise<any> {
    return this.fetch('/stats/dashboard', { skipRedirect });
  }

  // Reports
  async downloadReport(agentId: string): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/reports/${agentId}/pdf`, {
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });
    if (!response.ok) throw new Error('Failed to download report');

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `report_${agentId}.pdf`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
  }

  // Socket.IO — training with race-condition-free start
  connectTraining(agentId: string, config: any, onUpdate: (data: TrainingProgress) => void): any {
    if (this.socket) this.socket.disconnect();

    this.socket = io('/training', {
      auth: { token: this.token }
    });

    this.socket.on('connect', () => {
      // Step 1: Join the room
      this.socket?.emit('join', { agent_id: agentId });
    });

    // Step 2: Room join is confirmed — now it's safe to start training
    this.socket.on('join_ack', ({ agent_id }: { agent_id: string }) => {
      if (agent_id === agentId) {
        this.socket?.emit('start_training', { agent_id: agentId, config });
      }
    });

    this.socket.on('training_update', (data: any) => {
      // Map backend snake_case to frontend camelCase if needed, or pass through
      const progress: TrainingProgress = {
        ...data,
        currentEpisode: data.episode,
        totalEpisodes: data.total_episodes || config.episodes || 1000,
        avgReward: data.reward,
        winRate: data.win_rate || 0,
        epsilon: data.epsilon || 0,
        rewardHistory: data.reward_history || [],
        winRateHistory: data.win_rate_history || []
      };
      onUpdate(progress);
    });

    return this.socket;
  }

  // Socket.IO
  connectArena(onUpdate: (data: any) => void): any {
    if (this.socket) this.socket.disconnect();

    this.socket = io('/arena', {
      auth: { token: this.token }
    });

    this.socket.on('arena_state', (data: any) => {
      onUpdate(data);
    });

    this.socket.on('arena_complete', (data: any) => {
      onUpdate({ ...data, gameOver: true });
    });

    return this.socket;
  }

  startMatch(agent1Id: string, agent2Id: string, game: string) {
    if (this.socket) {
      this.socket.emit('start_match', {
        agent1_id: agent1Id,
        agent2_id: agent2Id,
        game: game
      });
    }
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }
}

export const api = new ArenaAPI();

// Keep these for internal mapping if needed, but they are no longer "The Source"
export const mockGames: Game[] = [
  { id: 'connect4', name: 'Connect 4', description: 'Drop discs to connect four', boardSize: [6, 7], supportedAgents: ['dqn', 'ppo', 'human'] },
  { id: 'maze', name: 'Maze Navigator', description: 'Two-player maze race', boardSize: [15, 15], supportedAgents: ['qlearning', 'dqn', 'sarsa', 'human'] },
  { id: 'snake', name: 'Snake', description: 'Two-player snake competition', boardSize: [20, 20], supportedAgents: ['dqn', 'qlearning', 'ppo', 'human'] },
  { id: 'pong', name: 'Pong', description: 'Classic Pong — human vs AI', boardSize: [100, 160], supportedAgents: ['dqn', 'ppo', 'a2c', 'human'] },
  { id: 'flappybird', name: 'Flappy Bird', description: 'Two-player pipe dodging', boardSize: [288, 512], supportedAgents: ['dqn', 'ppo', 'a2c', 'human'] },
  { id: 'dodge', name: 'Dodge', description: 'Avoid falling obstacles', boardSize: [10, 10], supportedAgents: ['dqn', 'ppo', 'sarsa', 'human'] },
  { id: '2048', name: '2048', description: 'Classic tile-merging game', boardSize: [4, 4], supportedAgents: ['dqn', 'qlearning', 'human'] },
  { id: 'breakout', name: 'Breakout', description: 'Destroy bricks with a ball', boardSize: [100, 160], supportedAgents: ['dqn', 'ppo', 'human'] },
  { id: 'treasurehunt', name: 'Grid Treasure Hunt', description: 'Find treasure, avoid traps', boardSize: [5, 5], supportedAgents: ['qlearning', 'sarsa', 'human'] },
  { id: 'balloonpop', name: 'Balloon Pop', description: 'Aim and pop balloons', boardSize: [100, 100], supportedAgents: ['dqn', 'a2c', 'human'] },
];
