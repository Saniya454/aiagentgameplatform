import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Brain, Activity, Zap, Cpu, Network } from 'lucide-react';
import { cn } from '@/lib/utils';

interface NeuralSynapseMonitorProps {
    reward: number;
    winRate: number;
    epsilon: number;
    agentId: string;
    isTraining: boolean;
}

export function NeuralSynapseMonitor({ reward, winRate, epsilon, agentId, isTraining }: NeuralSynapseMonitorProps) {
    const [nodes, setNodes] = useState<boolean[]>(Array(24).fill(false));
    const [lastReward, setLastReward] = useState(reward);
    const [delta, setDelta] = useState(0);

    // Simulate neural pulsing when training is active
    useEffect(() => {
        if (!isTraining) return;

        const interval = setInterval(() => {
            setNodes(prev => prev.map(() => Math.random() > 0.7));
        }, 150); // High-speed blink

        return () => clearInterval(interval);
    }, [isTraining]);

    // Track reward delta
    useEffect(() => {
        if (reward !== lastReward) {
            setDelta(reward - lastReward);
            setLastReward(reward);
        }
    }, [reward, lastReward]);

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Synapse Grid */}
            <Card className="glass border-primary/20 bg-primary/5 lg:col-span-1">
                <CardHeader className="py-3">
                    <CardTitle className="text-sm font-mono flex items-center gap-2">
                        <Network className="w-4 h-4 text-primary" />
                        Neural Synapse Grid
                    </CardTitle>
                </CardHeader>
                <CardContent className="p-4 flex items-center justify-center">
                    <div className="grid grid-cols-6 gap-2">
                        {nodes.map((active, i) => (
                            <div
                                key={i}
                                className={cn(
                                    "w-3 h-3 rounded-full transition-all duration-100",
                                    active && isTraining
                                        ? "bg-primary shadow-[0_0_8px_var(--primary)] scale-110"
                                        : "bg-primary/10 scale-100"
                                )}
                            />
                        ))}
                    </div>
                </CardContent>
                <div className="px-4 pb-3 text-[10px] font-mono text-primary/60 flex justify-between uppercase">
                    <span>Matrix: 24-Node</span>
                    <span>Freq: 15Hz</span>
                </div>
            </Card>

            {/* Decision Telemetry */}
            <Card className="glass border-accent/20 bg-accent/5 lg:col-span-2">
                <CardHeader className="py-3 flex flex-row items-center justify-between">
                    <CardTitle className="text-sm font-mono flex items-center gap-2">
                        <Cpu className="w-4 h-4 text-accent" />
                        Decision Telemetry Matrix
                    </CardTitle>
                    <div className="px-2 py-0.5 bg-accent/20 text-accent rounded text-[10px] font-bold animate-pulse">
                        HIGH-SPEED DATA
                    </div>
                </CardHeader>
                <CardContent className="p-4 grid grid-cols-3 gap-4">
                    <div className="space-y-1">
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">Rolling Reward</p>
                        <div className="flex items-baseline gap-2">
                            <p className="text-2xl font-mono font-bold text-accent">{reward.toFixed(2)}</p>
                            <span className={cn(
                                "text-[10px] font-bold",
                                delta > 0 ? "text-green-500" : delta < 0 ? "text-red-500" : "text-muted-foreground"
                            )}>
                                {delta > 0 ? '↑' : delta < 0 ? '↓' : '•'} {Math.abs(delta).toFixed(2)}
                            </span>
                        </div>
                    </div>
                    <div className="space-y-1">
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">Win Rate</p>
                        <p className="text-2xl font-mono font-bold text-primary">{(winRate * 100).toFixed(1)}%</p>
                    </div>
                    <div className="space-y-1">
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">Network ε</p>
                        <p className="text-2xl font-mono font-bold text-muted-foreground">{epsilon.toFixed(3)}</p>
                    </div>
                </CardContent>
                <div className="border-t border-accent/10 px-4 py-2 bg-accent/5">
                    <div className="flex items-center gap-2 text-[10px] font-mono whitespace-nowrap overflow-hidden">
                        <span className="text-accent underline">STATUS:</span>
                        <span className="text-muted-foreground animate-pulse">Receiving real-time performance vectors from Agent_{agentId}...</span>
                    </div>
                </div>
            </Card>
        </div>
    );
}
