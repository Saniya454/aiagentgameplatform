import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { useAgents, useGames, useTraining } from '@/hooks/useArenaAPI';
import { TrainingConsole } from '@/components/training/TrainingConsole';
import { TrainingPreview } from '@/components/training/TrainingPreview';
import { NeuralSynapseMonitor } from '@/components/training/NeuralSynapseMonitor';
import { Brain, Play, Square, Zap, Target, Trash2, Plus, Gauge, Timer, Star, Cpu } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';

export default function Train() {
  const [searchParams] = useSearchParams();
  const initialGame = searchParams.get('game') || 'tictactoe';

  const { agents, deleteAgent } = useAgents();
  const { games } = useGames();
  const { progress, isTraining, startTraining, stopTraining } = useTraining();

  const [selectedAgentId, setSelectedAgentId] = useState<string>('new');
  const [agentName, setAgentName] = useState('My AI Agent');
  const [selectedAlgorithm, setSelectedAlgorithm] = useState('dqn');
  const [selectedGame, setSelectedGame] = useState(initialGame);
  const [episodes, setEpisodes] = useState(1000);
  const [learningRate, setLearningRate] = useState(0.001);

  // Update fields when selecting an existing agent
  useEffect(() => {
    if (selectedAgentId !== 'new') {
      const agent = agents.find(a => a.id === selectedAgentId);
      if (agent) {
        setAgentName(agent.name);
        setSelectedGame(agent.game);
        setSelectedAlgorithm(agent.algorithm);
        // Episodes and LR can stay as they are or be updated if the agent has them recorded
      }
    }
  }, [selectedAgentId, agents]);

  const algorithms = [
    {
      id: 'q-learning',
      name: 'Q-Learning',
      description: 'Tabular reinforcement learning that learns the value of actions in each state.',
      bestFor: 'Snake, Pong, Maze'
    },
    {
      id: 'sarsa',
      name: 'SARSA',
      description: 'On-policy learning that updates values based on the actual next action taken.',
      bestFor: 'Grid Treasure Hunt, Maze'
    },
    {
      id: 'dqn',
      name: 'DQN',
      description: 'Uses Deep Neural Networks to estimate Q-values for large state spaces.',
      bestFor: 'Connect 4, Flappy Bird, 2048'
    },
    {
      id: 'ppo',
      name: 'PPO',
      description: 'Policy gradient method that ensures stable updates during training.',
      bestFor: 'Dodge, Balloon Pop, Breakout'
    },
    {
      id: 'a2c',
      name: 'A2C',
      description: 'Synchronous actor-critic method that combines policy and value estimates.',
      bestFor: 'Dodge, Balloon Pop'
    },
  ];

  const handleStartTraining = () => {
    startTraining(
      agentName,
      selectedGame,
      episodes,
      selectedAlgorithm,
      learningRate
    );
  };

  const handleDelete = async () => {
    if (selectedAgentId === 'new') return;
    const success = await deleteAgent(selectedAgentId);
    if (success) {
      setSelectedAgentId('new');
      setAgentName('My AI Agent');
    }
  };

  return (
    <MainLayout>
      <div className="max-w-6xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-mono font-bold mb-2 flex items-center gap-3">
            <Brain className="w-8 h-8 text-primary" />
            Train Agents
          </h1>
          <p className="text-muted-foreground">
            Configure and train reinforcement learning agents with live progress visualization.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Configuration Panel */}
          <Card className="glass lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                Training Configuration
              </CardTitle>
              <CardDescription>Set up your training session</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Agent Selection */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Select or Create Agent</Label>
                  {selectedAgentId !== 'new' && !isTraining && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 text-destructive hover:text-destructive hover:bg-destructive/10 gap-1 px-2"
                      onClick={handleDelete}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Delete
                    </Button>
                  )}
                </div>
                <Select value={selectedAgentId} onValueChange={setSelectedAgentId} disabled={isTraining}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose an agent..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">
                      <div className="flex items-center gap-2">
                        <Plus className="w-4 h-4 text-primary" />
                        <span>Create New Agent</span>
                      </div>
                    </SelectItem>
                    {agents.map((agent) => (
                      <SelectItem key={agent.id} value={agent.id}>
                        {agent.name} ({agent.game})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* New Agent Name (Conditional) */}
              {selectedAgentId === 'new' && (
                <div className="space-y-2 animate-in fade-in slide-in-from-top-2 duration-300">
                  <Label>Agent Name</Label>
                  <Input
                    value={agentName}
                    onChange={(e) => setAgentName(e.target.value)}
                    placeholder="Enter new agent name..."
                    disabled={isTraining}
                  />
                </div>
              )}

              {/* Algorithm Selection */}
              <div className="space-y-2">
                <Label>Algorithm</Label>
                <Select value={selectedAlgorithm} onValueChange={setSelectedAlgorithm} disabled={isTraining || selectedAgentId !== 'new'}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {algorithms.map((algo) => (
                      <SelectItem key={algo.id} value={algo.id}>
                        {algo.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Game Selection */}
              <div className="space-y-2">
                <Label>Game Environment</Label>
                <Select value={selectedGame} onValueChange={setSelectedGame} disabled={isTraining || selectedAgentId !== 'new'}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {games.map((game) => (
                      <SelectItem key={game.id} value={game.id}>
                        {game.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Episodes */}
              <div className="space-y-2">
                <Label>Training Episodes</Label>
                <Input
                  type="number"
                  value={episodes}
                  onChange={(e) => setEpisodes(parseInt(e.target.value) || 1000)}
                  disabled={isTraining}
                  min={100}
                  max={100000}
                  step={1000}
                />
              </div>

              {/* Learning Rate */}
              <div className="space-y-2">
                <Label>Learning Rate</Label>
                <Input
                  type="number"
                  value={learningRate}
                  onChange={(e) => setLearningRate(parseFloat(e.target.value) || 0.001)}
                  disabled={isTraining}
                  min={0.0001}
                  max={0.1}
                  step={0.0001}
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-4 space-y-3">
                {!isTraining ? (
                  <Button
                    onClick={handleStartTraining}
                    className="w-full gap-2"
                    size="lg"
                  >
                    <Play className="w-5 h-5" />
                    Start Training
                  </Button>
                ) : (
                  <Button
                    onClick={stopTraining}
                    variant="destructive"
                    className="w-full gap-2"
                    size="lg"
                  >
                    <Square className="w-5 h-5" />
                    Stop Training
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Training Progress */}
          <div className="lg:col-span-2 space-y-6">
            {/* Progress & Metrics */}
            {progress && (
              <div className="space-y-6">
                <Card className="glass border-primary/20 bg-primary/5">
                  <CardContent className="py-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="flex items-center gap-2 font-mono text-sm font-bold uppercase tracking-tighter text-primary">
                        <Zap className="w-4 h-4 animate-pulse" />
                        Iteration Progress
                      </span>
                      <span className="font-mono text-xs font-bold text-muted-foreground">
                        [{progress.currentEpisode} / {progress.totalEpisodes}]
                      </span>
                    </div>
                    <Progress
                      value={(progress.currentEpisode / progress.totalEpisodes) * 100}
                      className="h-2 bg-primary/10"
                    />
                  </CardContent>
                </Card>

                <NeuralSynapseMonitor
                  agentId={selectedAgentId || 'unknown'}
                  reward={progress.reward || 0}
                  winRate={progress.winRate || 0}
                  epsilon={progress.epsilon || 0}
                  isTraining={progress.status === 'training' || isTraining}
                />
              </div>
            )}

            <div className="space-y-4">
              <TrainingPreview board={progress?.board} gameId={selectedGame} />
              <TrainingConsole logs={progress?.logs || []} />
            </div>

            {/* Algorithm Info Cards */}
            <div className="grid md:grid-cols-2 gap-4">
              {algorithms.map((algo) => (
                <Card
                  key={algo.id}
                  className={`glass transition-all ${selectedAlgorithm === algo.id ? 'border-primary glow-primary' : ''
                    }`}
                >
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Brain className="w-5 h-5 text-primary" />
                      {algo.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-3">
                      {algo.description}
                    </p>
                    <div className="flex items-center gap-2 text-xs font-bold text-primary bg-primary/5 p-2 rounded border border-primary/10">
                      <Star className="w-3.5 h-3.5" />
                      Best Suited For: {algo.bestFor}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
